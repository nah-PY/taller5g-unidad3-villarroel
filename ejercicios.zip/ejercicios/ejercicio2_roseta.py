from PIL import Image
import math
import colorsys

def bresenham(pixels, x0, y0, x1, y1, color, ancho, alto):
    x0 = int(x0)
    y0 = int(y0)
    x1 = int(x1)
    y1 = int(y1)
    dx = abs(x1 - x0)
    dy = abs(y1 - y0)
    if x0 < x1:
        sx = 1
    else:
        sx = -1
    if y0 < y1:
        sy = 1
    else:
        sy = -1
    err = dx - dy
    while True:
        if x0 >= 0 and x0 < ancho and y0 >= 0 and y0 < alto:
            pixels[x0, y0] = color
        if x0 == x1 and y0 == y1:
            break
        e2 = 2 * err
        if e2 > -dy:
            err = err - dy
            x0 = x0 + sx
        if e2 < dx:
            err = err + dx
            y0 = y0 + sy

def generar_puntos_circulo(cx, cy, radio, n):
    puntos = []
    for i in range(n):
        angulo = 2 * math.pi * i / n
        x = cx + int(radio * math.cos(angulo))
        y = cy + int(radio * math.sin(angulo))
        puntos.append((x, y))
    return puntos

def dibujar_roseta(pixels, puntos, ancho, alto):
    n = len(puntos)
    cx = ancho / 2
    cy = alto / 2
    radio = math.sqrt((puntos[0][0] - cx) ** 2 + (puntos[0][1] - cy) ** 2)
    cont = 0
    for i in range(n):
        for j in range(i + 1, n):
            mx = (puntos[i][0] + puntos[j][0]) / 2
            my = (puntos[i][1] + puntos[j][1]) / 2
            d = math.sqrt((mx - cx) ** 2 + (my - cy) ** 2) / radio
            c = colorsys.hsv_to_rgb(d * 0.8, 1, 1)
            color = (int(c[0] * 255), int(c[1] * 255), int(c[2] * 255))
            bresenham(pixels, puntos[i][0], puntos[i][1], puntos[j][0], puntos[j][1], color, ancho, alto)
            cont = cont + 1
    print("lineas:", cont)

for n in [12, 24, 36]:
    img = Image.new("RGB", (700, 700), "black")
    pixels = img.load()
    puntos = generar_puntos_circulo(350, 350, 300, n)
    dibujar_roseta(pixels, puntos, 700, 700)
    img.save("roseta_" + str(n) + ".png")
    if n == 24:
        img.save("roseta.png")
