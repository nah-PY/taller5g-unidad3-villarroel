from PIL import Image
import math

def dda(pixels, x0, y0, x1, y1, color, ancho, alto):
    dx = x1 - x0
    dy = y1 - y0
    if abs(dx) > abs(dy):
        pasos = abs(dx)
    else:
        pasos = abs(dy)
    if pasos == 0:
        pixels[int(x0), int(y0)] = color
        return
    xi = dx / pasos
    yi = dy / pasos
    x = x0
    y = y0
    i = 0
    while i <= pasos:
        if x >= 0 and x < ancho and y >= 0 and y < alto:
            pixels[int(round(x)), int(round(y))] = color
        x = x + xi
        y = y + yi
        i = i + 1

def dibujar_rectangulo(pixels, x0, y0, x1, y1, color, ancho, alto):
    dda(pixels, x0, y0, x1, y0, color, ancho, alto)
    dda(pixels, x1, y0, x1, y1, color, ancho, alto)
    dda(pixels, x0, y1, x1, y1, color, ancho, alto)
    dda(pixels, x0, y0, x0, y1, color, ancho, alto)

def dibujar_triangulo(pixels, p1, p2, p3, color, ancho, alto):
    dda(pixels, p1[0], p1[1], p2[0], p2[1], color, ancho, alto)
    dda(pixels, p2[0], p2[1], p3[0], p3[1], color, ancho, alto)
    dda(pixels, p3[0], p3[1], p1[0], p1[1], color, ancho, alto)

def dibujar_puerta(pixels, color, ancho, alto):
    dda(pixels, 275, 340, 325, 340, color, ancho, alto)
    dda(pixels, 325, 340, 325, 420, color, ancho, alto)
    dda(pixels, 275, 420, 325, 420, color, ancho, alto)
    dda(pixels, 275, 340, 275, 420, color, ancho, alto)

def dibujar_ventana1(pixels, color, ancho, alto):
    dda(pixels, 215, 305, 255, 305, color, ancho, alto)
    dda(pixels, 255, 305, 255, 345, color, ancho, alto)
    dda(pixels, 215, 345, 255, 345, color, ancho, alto)
    dda(pixels, 215, 305, 215, 345, color, ancho, alto)

def dibujar_ventana2(pixels, color, ancho, alto):
    dda(pixels, 345, 305, 385, 305, color, ancho, alto)
    dda(pixels, 385, 305, 385, 345, color, ancho, alto)
    dda(pixels, 345, 345, 385, 345, color, ancho, alto)
    dda(pixels, 345, 305, 345, 345, color, ancho, alto)

def dibujar_sol(pixels, cx, cy, radio, n_rayos, color, ancho, alto):
    for i in range(n_rayos):
        a = i * 2 * math.pi / n_rayos
        x2 = cx + math.cos(a) * radio
        y2 = cy + math.sin(a) * radio
        dda(pixels, cx, cy, x2, y2, color, ancho, alto)

def dibujar_piso(pixels, color, ancho, alto):
    dda(pixels, 0, 420, 599, 420, color, ancho, alto)

ancho = 600
alto = 500
imagen = Image.new("RGB", (ancho, alto), (200, 230, 255))
pixels = imagen.load()

dibujar_piso(pixels, (0, 0, 0), ancho, alto)
dibujar_rectangulo(pixels, 200, 280, 400, 420, (255, 0, 0), ancho, alto)
dibujar_triangulo(pixels, (180, 280), (420, 280), (300, 170), (120, 60, 0), ancho, alto)
dibujar_puerta(pixels, (0, 0, 255), ancho, alto)
dibujar_ventana1(pixels, (0, 150, 0), ancho, alto)
dibujar_ventana2(pixels, (0, 150, 0), ancho, alto)
dibujar_sol(pixels, 520, 80, 50, 12, (255, 200, 0), ancho, alto)

imagen.save("casa.png")
print("listo")
